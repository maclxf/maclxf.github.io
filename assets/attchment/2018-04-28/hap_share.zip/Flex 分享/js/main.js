
$(document).ready(function () {
	$(".item").hide();
	$("button").on("click", function () {
		$(this).next(".item").stop().slideToggle(500);
	});
});
